import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Issue, Priority, Status } from '@/types/issue';
import { toast } from 'sonner';

interface IssueContextType {
  issues: Issue[];
  addIssue: (issue: Omit<Issue, 'id' | 'createdAt'>) => void;
  updateIssueStatus: (id: string, newStatus: Status) => boolean;
  findSimilarIssues: (title: string, description: string) => Issue[];
  filterIssues: (status?: Status, priority?: Priority) => Issue[];
}

const IssueContext = createContext<IssueContextType | undefined>(undefined);

export const useIssues = () => {
  const context = useContext(IssueContext);
  if (!context) {
    throw new Error('useIssues must be used within an IssueProvider');
  }
  return context;
};

interface IssueProviderProps {
  children: ReactNode;
}

// Helper function to calculate text similarity
const calculateSimilarity = (str1: string, str2: string): number => {
  const s1 = str1.toLowerCase();
  const s2 = str2.toLowerCase();
  
  // Simple word overlap similarity
  const words1 = s1.split(/\s+/).filter(w => w.length > 2);
  const words2 = s2.split(/\s+/).filter(w => w.length > 2);
  
  if (words1.length === 0 || words2.length === 0) return 0;
  
  const commonWords = words1.filter(w => words2.includes(w));
  return (commonWords.length * 2) / (words1.length + words2.length);
};

export const IssueProvider: React.FC<IssueProviderProps> = ({ children }) => {
  const [issues, setIssues] = useState<Issue[]>([]);

  useEffect(() => {
    // Load issues from localStorage
    const storedIssues = localStorage.getItem('issueBoard_issues');
    if (storedIssues) {
      const parsed = JSON.parse(storedIssues);
      // Convert date strings back to Date objects
      setIssues(parsed.map((issue: Issue & { createdAt: string }) => ({
        ...issue,
        createdAt: new Date(issue.createdAt)
      })));
    }
  }, []);

  const saveIssues = (newIssues: Issue[]) => {
    localStorage.setItem('issueBoard_issues', JSON.stringify(newIssues));
    setIssues(newIssues);
  };

  const addIssue = (issueData: Omit<Issue, 'id' | 'createdAt'>) => {
    const newIssue: Issue = {
      ...issueData,
      id: 'issue_' + Date.now(),
      createdAt: new Date(),
    };
    
    const updatedIssues = [newIssue, ...issues];
    saveIssues(updatedIssues);
    toast.success('Issue created successfully!');
  };

  const updateIssueStatus = (id: string, newStatus: Status): boolean => {
    const issue = issues.find(i => i.id === id);
    
    if (!issue) return false;
    
    // Check if trying to move directly from Open to Done
    if (issue.status === 'Open' && newStatus === 'Done') {
      toast.error('Cannot move issue directly from Open to Done. Please move it to "In Progress" first.');
      return false;
    }
    
    const updatedIssues = issues.map(i => 
      i.id === id ? { ...i, status: newStatus } : i
    );
    
    saveIssues(updatedIssues);
    toast.success(`Issue status updated to ${newStatus}`);
    return true;
  };

  const findSimilarIssues = (title: string, description: string): Issue[] => {
    if (!title && !description) return [];
    
    const combinedText = `${title} ${description}`;
    
    return issues.filter(issue => {
      const issueText = `${issue.title} ${issue.description}`;
      const similarity = calculateSimilarity(combinedText, issueText);
      return similarity > 0.3; // 30% similarity threshold
    }).slice(0, 3); // Return top 3 similar issues
  };

  const filterIssues = (status?: Status, priority?: Priority): Issue[] => {
    return issues
      .filter(issue => {
        if (status && issue.status !== status) return false;
        if (priority && issue.priority !== priority) return false;
        return true;
      })
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()); // Newest first
  };

  return (
    <IssueContext.Provider value={{ issues, addIssue, updateIssueStatus, findSimilarIssues, filterIssues }}>
      {children}
    </IssueContext.Provider>
  );
};
