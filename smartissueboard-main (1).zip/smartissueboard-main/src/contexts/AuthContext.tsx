import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/types/issue';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user on mount
    const storedUser = localStorage.getItem('issueBoard_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<void> => {
    // Simulate auth - in production, this would use Firebase Auth
    const users = JSON.parse(localStorage.getItem('issueBoard_users') || '[]');
    const existingUser = users.find((u: { email: string; password: string }) => 
      u.email === email && u.password === password
    );
    
    if (!existingUser) {
      throw new Error('Invalid email or password');
    }
    
    const userData: User = { email, uid: existingUser.uid };
    setUser(userData);
    localStorage.setItem('issueBoard_user', JSON.stringify(userData));
  };

  const signup = async (email: string, password: string): Promise<void> => {
    // Simulate auth - in production, this would use Firebase Auth
    const users = JSON.parse(localStorage.getItem('issueBoard_users') || '[]');
    const existingUser = users.find((u: { email: string }) => u.email === email);
    
    if (existingUser) {
      throw new Error('User already exists');
    }
    
    const uid = 'user_' + Date.now();
    users.push({ email, password, uid });
    localStorage.setItem('issueBoard_users', JSON.stringify(users));
    
    const userData: User = { email, uid };
    setUser(userData);
    localStorage.setItem('issueBoard_user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('issueBoard_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
