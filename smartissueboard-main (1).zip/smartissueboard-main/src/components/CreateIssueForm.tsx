import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useIssues } from '@/contexts/IssueContext';
import { Priority, Status, Issue } from '@/types/issue';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, Plus, X } from 'lucide-react';

interface CreateIssueFormProps {
  onClose: () => void;
}

const CreateIssueForm: React.FC<CreateIssueFormProps> = ({ onClose }) => {
  const { user } = useAuth();
  const { addIssue, findSimilarIssues } = useIssues();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [status, setStatus] = useState<Status>('Open');
  const [assignedTo, setAssignedTo] = useState('');
  const [similarIssues, setSimilarIssues] = useState<Issue[]>([]);
  const [showSimilarWarning, setShowSimilarWarning] = useState(false);
  const [confirmedSimilar, setConfirmedSimilar] = useState(false);

  useEffect(() => {
    // Debounce similarity check
    const timer = setTimeout(() => {
      if (title.length > 3 || description.length > 10) {
        const similar = findSimilarIssues(title, description);
        setSimilarIssues(similar);
        setShowSimilarWarning(similar.length > 0);
        setConfirmedSimilar(false);
      } else {
        setSimilarIssues([]);
        setShowSimilarWarning(false);
      }
    }, 300);
    
    return () => clearTimeout(timer);
  }, [title, description, findSimilarIssues]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) return;
    
    // Check for similar issues and require confirmation
    if (showSimilarWarning && !confirmedSimilar) {
      return;
    }
    
    addIssue({
      title: title.trim(),
      description: description.trim(),
      priority,
      status,
      assignedTo: assignedTo.trim() || user?.email || 'Unassigned',
      createdBy: user?.email || 'Unknown',
    });
    
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/20 backdrop-blur-sm p-4">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto animate-fade-in shadow-xl">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="text-xl font-semibold">Create New Issue</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                placeholder="Brief summary of the issue"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Detailed description of the issue..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            
            {showSimilarWarning && (
              <Alert className="border-priority-medium/50 bg-priority-medium/10">
                <AlertTriangle className="h-4 w-4 text-priority-medium" />
                <AlertTitle className="text-priority-medium font-medium">Similar issues found</AlertTitle>
                <AlertDescription className="mt-2">
                  <p className="text-sm text-muted-foreground mb-2">
                    We found {similarIssues.length} similar issue(s). Consider checking these before creating a new one:
                  </p>
                  <ul className="space-y-1 text-sm">
                    {similarIssues.map(issue => (
                      <li key={issue.id} className="text-foreground/80">
                        • {issue.title} <span className="text-muted-foreground">({issue.status})</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setConfirmedSimilar(true)}
                      className={confirmedSimilar ? 'border-status-done text-status-done' : ''}
                    >
                      {confirmedSimilar ? '✓ Confirmed - Create anyway' : 'I understand, create anyway'}
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">🟢 Low</SelectItem>
                    <SelectItem value="Medium">🟡 Medium</SelectItem>
                    <SelectItem value="High">🔴 High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={status} onValueChange={(v) => setStatus(v as Status)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Done">Done</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="assignedTo">Assigned To</Label>
              <Input
                id="assignedTo"
                type="email"
                placeholder={user?.email || 'user@example.com'}
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3 pt-2">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1"
                disabled={showSimilarWarning && !confirmedSimilar}
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Issue
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateIssueForm;
