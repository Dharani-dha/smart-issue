import React, { useState } from 'react';
import Header from './Header';
import IssueList from './IssueList';
import CreateIssueForm from './CreateIssueForm';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [showCreateForm, setShowCreateForm] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-6 md:py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Issues</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage and track all your issues in one place
            </p>
          </div>
          <Button onClick={() => setShowCreateForm(true)} size="default">
            <Plus className="w-4 h-4 mr-2" />
            New Issue
          </Button>
        </div>
        
        <IssueList />
      </main>
      
      {showCreateForm && (
        <CreateIssueForm onClose={() => setShowCreateForm(false)} />
      )}
    </div>
  );
};

export default Dashboard;
