import React, { useState } from 'react';
import { useIssues } from '@/contexts/IssueContext';
import { Priority, Status } from '@/types/issue';
import IssueCard from './IssueCard';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Filter, X, Inbox } from 'lucide-react';

const IssueList: React.FC = () => {
  const { filterIssues } = useIssues();
  const [statusFilter, setStatusFilter] = useState<Status | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'all'>('all');

  const filteredIssues = filterIssues(
    statusFilter === 'all' ? undefined : statusFilter,
    priorityFilter === 'all' ? undefined : priorityFilter
  );

  const hasFilters = statusFilter !== 'all' || priorityFilter !== 'all';

  const clearFilters = () => {
    setStatusFilter('all');
    setPriorityFilter('all');
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 p-4 bg-card rounded-lg border border-border/50">
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <Filter className="w-4 h-4" />
          <span>Filters</span>
        </div>
        
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as Status | 'all')}>
          <SelectTrigger className="w-[140px] h-9">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="Open">Open</SelectItem>
            <SelectItem value="In Progress">In Progress</SelectItem>
            <SelectItem value="Done">Done</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={priorityFilter} onValueChange={(v) => setPriorityFilter(v as Priority | 'all')}>
          <SelectTrigger className="w-[140px] h-9">
            <SelectValue placeholder="Priority" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Priority</SelectItem>
            <SelectItem value="High">🔴 High</SelectItem>
            <SelectItem value="Medium">🟡 Medium</SelectItem>
            <SelectItem value="Low">🟢 Low</SelectItem>
          </SelectContent>
        </Select>
        
        {hasFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
            <X className="w-4 h-4 mr-1" />
            Clear
          </Button>
        )}
        
        <div className="ml-auto text-sm text-muted-foreground">
          {filteredIssues.length} issue{filteredIssues.length !== 1 ? 's' : ''}
        </div>
      </div>
      
      {/* Issue Grid */}
      {filteredIssues.length > 0 ? (
        <div className="grid gap-3">
          {filteredIssues.map((issue) => (
            <IssueCard key={issue.id} issue={issue} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-4">
            <Inbox className="w-8 h-8 text-muted-foreground/50" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-1">No issues found</h3>
          <p className="text-sm text-muted-foreground">
            {hasFilters 
              ? 'Try adjusting your filters or create a new issue.'
              : 'Create your first issue to get started.'}
          </p>
        </div>
      )}
    </div>
  );
};

export default IssueList;
