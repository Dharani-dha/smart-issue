import React from 'react';
import { Issue, Status } from '@/types/issue';
import { useIssues } from '@/contexts/IssueContext';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Clock, User } from 'lucide-react';
import { format } from 'date-fns';

interface IssueCardProps {
  issue: Issue;
}

const IssueCard: React.FC<IssueCardProps> = ({ issue }) => {
  const { updateIssueStatus } = useIssues();

  const handleStatusChange = (newStatus: Status) => {
    updateIssueStatus(issue.id, newStatus);
  };

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case 'High': return 'priority-high';
      case 'Medium': return 'priority-medium';
      case 'Low': return 'priority-low';
      default: return '';
    }
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'Open': return 'status-open';
      case 'In Progress': return 'status-progress';
      case 'Done': return 'status-done';
      default: return '';
    }
  };

  return (
    <Card className="group hover:shadow-md transition-all duration-200 border-border/50 animate-fade-in">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={`${getPriorityClass(issue.priority)} text-xs font-medium`}>
                {issue.priority}
              </Badge>
              <Badge variant="outline" className={`${getStatusClass(issue.status)} text-xs font-medium border-0`}>
                {issue.status}
              </Badge>
            </div>
            
            <h3 className="font-medium text-foreground mb-1 truncate">{issue.title}</h3>
            
            {issue.description && (
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {issue.description}
              </p>
            )}
            
            <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                <span className="truncate max-w-[150px]">{issue.assignedTo}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{format(issue.createdAt, 'MMM d, yyyy')}</span>
              </div>
            </div>
          </div>
          
          <div className="flex-shrink-0">
            <Select value={issue.status} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[130px] h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Done">Done</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IssueCard;
